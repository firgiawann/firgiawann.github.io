const fs = require('fs');
const path = 'c:/Users/andri/Downloads/MY-PROFILE/MODUL/index.html';
let html = fs.readFileSync(path, 'utf8');

// Extract CSS
const styleRegex = /<style>([\s\S]*?)<\/style>/i;
const styleMatch = html.match(styleRegex);
if(styleMatch) {
    const cssContent = styleMatch[1];
    fs.mkdirSync('c:/Users/andri/Downloads/MY-PROFILE/MODUL/css', { recursive: true });
    fs.writeFileSync('c:/Users/andri/Downloads/MY-PROFILE/MODUL/css/style.css', cssContent.trim());
    html = html.replace(styleRegex, '<link rel="stylesheet" href="css/style.css">');
    console.log('Extracted CSS');
}

// Extract JS
const scriptRegex = /<script>([\s\S]*?)<\/script>/i;
// Since there's mainly ONE JS block at the bottom, let's just do it directly. If more, we handle accordingly.
// Wait, AOS might have <script>AOS.init();</script> maybe?
let updatedHtml = html;
let jsCombined = "";
const scripts = html.match(/<script>([\s\S]*?)<\/script>/gi);
if (scripts) {
    scripts.forEach((block, index) => {
        // extract the inner logic
        const inner = block.replace(/<\/?script>/ig, '');
        jsCombined += inner + "\n\n";
        
        if (index === 0) {
            updatedHtml = updatedHtml.replace(block, '<script src="js/script.js" defer></script>');
        } else {
            updatedHtml = updatedHtml.replace(block, '');
        }
    });
    fs.mkdirSync('c:/Users/andri/Downloads/MY-PROFILE/MODUL/js', { recursive: true });
    fs.writeFileSync('c:/Users/andri/Downloads/MY-PROFILE/MODUL/js/script.js', jsCombined.trim());
    console.log('Extracted JS');
}

fs.writeFileSync(path, updatedHtml);
console.log('Done.');
